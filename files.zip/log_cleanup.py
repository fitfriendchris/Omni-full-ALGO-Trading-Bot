"""
log_cleanup.py  —  OMNI Log & State Cleanup Manager
=====================================================
Prevents disk bloat and memory buildup from unlimited logging.

Features:
  • Auto-rotate log files when they exceed MAX_LOG_MB (default 5 MB)
  • Keep only last N rotated files
  • Purge old JSON state entries (trade_memory, closed trades)
  • Trim in-memory log buffers in the FastAPI server
  • Schedule cleanup to run automatically on a background thread

Usage:
    from log_cleanup import LogCleanup, setup_rotating_logger
    cleanup = LogCleanup(base_dir="/path/to/project")
    cleanup.start_background()          # runs every 30 min

    # Or: get a pre-configured rotating logger
    log = setup_rotating_logger("MyModule", "/path/to/logs/module.log")
"""

from __future__ import annotations

import gzip
import json
import logging
import logging.handlers
import os
import shutil
import threading
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

# ── Defaults ──────────────────────────────────────────────────────────────────
MAX_LOG_MB        = 5       # Rotate after this many MB
MAX_ROTATIONS     = 5       # Keep this many rotated files
MAX_JOURNAL_DAYS  = 30      # Delete journal entries older than this
MAX_MEMORY_TRADES = 500     # Cap trade_memory.json to this many trades
CLEANUP_INTERVAL  = 1800    # Seconds between automatic cleanup (30 min)

log = logging.getLogger("LogCleanup")


# ══════════════════════════════════════════════════════════════════════════════
# ROTATING LOGGER FACTORY
# ══════════════════════════════════════════════════════════════════════════════

def setup_rotating_logger(
    name:       str,
    log_path:   str,
    max_mb:     int = MAX_LOG_MB,
    backups:    int = MAX_ROTATIONS,
    level:      int = logging.INFO,
    fmt:        str = "%(asctime)s [%(levelname)s] %(message)s",
) -> logging.Logger:
    """
    Create (or retrieve) a logger with a RotatingFileHandler.
    Also attaches a StreamHandler so messages appear in the console.

    This is the ONLY logger factory you need — replace all basicConfig calls.
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # Already configured

    logger.setLevel(level)

    # Rotating file handler
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    file_handler = logging.handlers.RotatingFileHandler(
        log_path,
        maxBytes    = max_mb * 1024 * 1024,
        backupCount = backups,
        encoding    = "utf-8",
    )
    file_handler.setFormatter(logging.Formatter(fmt))
    logger.addHandler(file_handler)

    # Console handler
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter(fmt))
    logger.addHandler(stream_handler)

    return logger


# ══════════════════════════════════════════════════════════════════════════════
# LOG CLEANUP ENGINE
# ══════════════════════════════════════════════════════════════════════════════

class LogCleanup:
    """
    Background cleanup engine.  Handles:
      1. Manual/legacy log files that grow unbounded
      2. Trade journal trimming (too old or too large)
      3. trade_memory.json capping (keep only last N closed trades)
      4. Temp file / partial JSON cleanup
    """

    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir)
        self._thread: threading.Thread | None = None
        self._stop   = threading.Event()
        self._stats  = {
            "last_run":      "",
            "bytes_freed":   0,
            "files_rotated": 0,
            "trades_pruned": 0,
        }

    # ── Public API ────────────────────────────────────────────────────────────

    def run_now(self) -> dict:
        """Run all cleanup tasks immediately. Returns stats dict."""
        self._stats["last_run"] = datetime.now(timezone.utc).isoformat()
        bytes_freed = 0
        files_rotated = 0
        trades_pruned = 0

        # 1. Rotate large log files
        for pattern in ["*.log", "*.txt"]:
            for log_file in self.base_dir.rglob(pattern):
                if log_file.stat().st_size > MAX_LOG_MB * 1024 * 1024:
                    rotated = self._rotate_log(log_file)
                    if rotated:
                        files_rotated += 1
                        bytes_freed   += rotated

        # 2. Delete excess rotated files (.log.1, .log.2, .log.gz etc.)
        bytes_freed += self._prune_rotated_files()

        # 3. Trim trade_journal.log (keep last 30 days)
        for jf in self.base_dir.rglob("trade_journal*.log"):
            n = self._trim_journal(jf, days=MAX_JOURNAL_DAYS)
            trades_pruned += n

        # 4. Cap trade_memory.json
        for mf in self.base_dir.rglob("trade_memory*.json"):
            n = self._cap_memory(mf, max_trades=MAX_MEMORY_TRADES)
            trades_pruned += n

        # 5. Delete stale temp files
        bytes_freed += self._delete_stale_temps()

        self._stats.update({
            "bytes_freed":   bytes_freed,
            "files_rotated": files_rotated,
            "trades_pruned": trades_pruned,
        })

        if bytes_freed > 0 or files_rotated > 0:
            log.info(
                f"Cleanup done — freed {bytes_freed/1024/1024:.2f} MB, "
                f"rotated {files_rotated} files, pruned {trades_pruned} records"
            )

        return dict(self._stats)

    def start_background(self, interval: int = CLEANUP_INTERVAL):
        """Start cleanup on a daemon thread (non-blocking)."""
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, args=(interval,),
            daemon=True, name="LogCleanup"
        )
        self._thread.start()
        log.info(f"LogCleanup started — interval {interval}s")

    def stop(self):
        self._stop.set()

    @property
    def stats(self) -> dict:
        return dict(self._stats)

    # ── Internal workers ──────────────────────────────────────────────────────

    def _loop(self, interval: int):
        while not self._stop.is_set():
            try:
                self.run_now()
            except Exception as e:
                log.error(f"Cleanup error: {e}")
            self._stop.wait(interval)

    def _rotate_log(self, path: Path) -> int:
        """
        Compress and rotate a large log file.
        Returns bytes freed.
        """
        try:
            gz_path = path.with_suffix(path.suffix + ".1.gz")
            size_before = path.stat().st_size

            with open(path, "rb") as f_in:
                with gzip.open(gz_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)

            # Truncate original (so the running logger keeps its handle)
            with open(path, "w") as f:
                f.write(f"# Log rotated at {datetime.now(timezone.utc).isoformat()}\n")

            size_after = gz_path.stat().st_size
            saved = size_before - size_after
            log.debug(f"Rotated {path.name}: {size_before//1024}KB → {size_after//1024}KB")
            return saved
        except Exception as e:
            log.warning(f"Rotate error {path}: {e}")
            return 0

    def _prune_rotated_files(self) -> int:
        """Delete excess rotated log files, keep newest N."""
        freed = 0
        # Group by base name
        groups: dict[str, list[Path]] = {}
        for p in self.base_dir.rglob("*.gz"):
            base = str(p).split(".")[0]
            groups.setdefault(base, []).append(p)

        for base, files in groups.items():
            files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
            for old in files[MAX_ROTATIONS:]:
                try:
                    freed += old.stat().st_size
                    old.unlink()
                    log.debug(f"Deleted old rotation: {old.name}")
                except Exception:
                    pass

        # Also delete numbered log files (.log.1 through .log.9 beyond limit)
        for p in self.base_dir.rglob("*.log.[1-9]"):
            try:
                num = int(p.suffix[1:])
                if num > MAX_ROTATIONS:
                    freed += p.stat().st_size
                    p.unlink()
            except Exception:
                pass

        return freed

    def _trim_journal(self, path: Path, days: int = 30) -> int:
        """
        Remove journal entries older than `days` days.
        Recognises the trade_journal.log separator format.
        """
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            cutoff  = datetime.now(timezone.utc) - timedelta(days=days)
            blocks  = content.split("━" * 64)
            kept, removed = [], 0

            for block in blocks:
                if not block.strip():
                    continue
                # Extract timestamp from first line: [2024-04-14 03:39:27 UTC]
                ts = None
                for line in block.splitlines():
                    if "[" in line and "UTC]" in line:
                        try:
                            ts_str = line.split("[")[1].split("]")[0].strip()
                            ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S UTC")
                            ts = ts.replace(tzinfo=timezone.utc)
                        except Exception:
                            pass
                        break
                if ts is None or ts >= cutoff:
                    kept.append(block)
                else:
                    removed += 1

            if removed > 0:
                sep = "━" * 64
                path.write_text(sep.join(kept), encoding="utf-8")
                log.debug(f"Journal {path.name}: removed {removed} old entries")

            return removed
        except Exception as e:
            log.warning(f"Journal trim error {path}: {e}")
            return 0

    def _cap_memory(self, path: Path, max_trades: int = MAX_MEMORY_TRADES) -> int:
        """
        Cap trade_memory.json to the most recent `max_trades` closed trades.
        Open trades are always kept.
        """
        try:
            with open(path) as f:
                data = json.load(f)

            trades = data.get("trades", {})
            open_trades   = {k: v for k, v in trades.items() if v.get("status") == "OPEN"}
            closed_trades = {k: v for k, v in trades.items() if v.get("status") != "OPEN"}

            if len(closed_trades) <= max_trades:
                return 0

            # Sort by open_time, keep newest
            sorted_closed = sorted(
                closed_trades.items(),
                key=lambda x: x[1].get("open_time", ""),
                reverse=True,
            )
            kept    = dict(sorted_closed[:max_trades])
            removed = len(sorted_closed) - max_trades

            data["trades"] = {**open_trades, **kept}

            # Rebuild summary
            closed_kept = list(kept.values())
            wins = sum(1 for t in closed_kept if t.get("status") == "WIN")
            data["summary"] = {
                "total_trades": len(closed_kept),
                "wins":         wins,
                "losses":       sum(1 for t in closed_kept if t.get("status") == "LOSS"),
                "win_rate_pct": round(wins / len(closed_kept) * 100, 1) if closed_kept else 0,
                "total_r":      round(sum(t.get("r_multiple", 0) for t in closed_kept), 2),
                "total_pnl_usd": round(sum(t.get("profit_usd", 0) for t in closed_kept), 2),
            }
            data["last_cleanup"] = datetime.now(timezone.utc).isoformat()

            with open(path, "w") as f:
                json.dump(data, f, indent=2)

            log.info(f"Memory capped: kept {max_trades} newest, removed {removed}")
            return removed

        except Exception as e:
            log.warning(f"Memory cap error {path}: {e}")
            return 0

    def _delete_stale_temps(self) -> int:
        """Delete temp files older than 1 hour."""
        freed = 0
        cutoff = time.time() - 3600
        for pattern in ["*.tmp", "omni_data.json.tmp", "*.bak"]:
            for p in self.base_dir.rglob(pattern):
                try:
                    if p.stat().st_mtime < cutoff:
                        freed += p.stat().st_size
                        p.unlink()
                except Exception:
                    pass
        return freed


# ══════════════════════════════════════════════════════════════════════════════
# CONVENIENCE: Install into the root auto_trader / server at startup
# ══════════════════════════════════════════════════════════════════════════════

_cleanup_instance: LogCleanup | None = None


def install(base_dir: str, interval: int = CLEANUP_INTERVAL) -> LogCleanup:
    """
    Create a global LogCleanup and start it.
    Call once at startup:
        from log_cleanup import install
        install("/path/to/project")
    """
    global _cleanup_instance
    _cleanup_instance = LogCleanup(base_dir)
    _cleanup_instance.start_background(interval)
    return _cleanup_instance


def get_cleanup() -> LogCleanup | None:
    return _cleanup_instance


if __name__ == "__main__":
    import sys
    base = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"Running one-time cleanup on: {base}")
    c = LogCleanup(base)
    stats = c.run_now()
    print(json.dumps(stats, indent=2))
