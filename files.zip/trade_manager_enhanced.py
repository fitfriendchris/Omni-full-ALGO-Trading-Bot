"""
trade_manager_enhanced.py  —  OMNI ICT Enhanced Trade Management v3.0
=======================================================================
Handles ALL active trade lifecycle:

  ✅ Partial exits at TP1 (50%), TP2 (30%), runner TP3 (20%)
  ✅ Trailing stop that NEVER lets a winner become a loser:
       0.5R → near break-even
       1.0R → true break-even
       1.5R → lock in 0.5R
       2.0R → lock in 1.0R
       3.0R → tight structural trail on M15
  ✅ Scale-in at 1R when push momentum confirmed
  ✅ Close runner immediately on opposing H1 BOS
  ✅ Opposing FVG / order block = early exit signal for runner

Import in auto_trader.py:
    from trade_manager_enhanced import TradeManager

Usage:
    mgr = TradeManager(state, send_command_fn, data_loader_fn, memory=memory)
    mgr.tick()   # Call every scan cycle (every 10 seconds)
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Callable, Optional

log = logging.getLogger("TradeManager")

try:
    from omni_dual_tf_engine import (
        parse_bars, calc_atr, swing_highs, swing_lows,
        compute_trailing_sl, find_ob_zones, find_fvgs,
        detect_mss, _h4_structure
    )
    _DTF_AVAILABLE = True
except ImportError:
    _DTF_AVAILABLE = False
    log.warning("omni_dual_tf_engine not found — trail logic uses ATR fallback")


# ══════════════════════════════════════════════════════════════════════════════
# ACTIVE TRADE RECORD
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ActiveTrade:
    ticket:         str
    symbol:         str
    direction:      str              # BUY | SELL
    entry_price:    float
    initial_sl:     float            # Original SL (never widen beyond this)
    current_sl:     float
    tp1:            float
    tp2:            float
    tp3:            float
    volume:         float
    risk_usd:       float
    entry_type:     str = ""
    memory_id:      str = ""

    # Management state
    tp1_taken:      bool  = False
    tp2_taken:      bool  = False
    be_triggered:   bool  = False    # SL at break-even or better
    scaled_in:      bool  = False
    scale_ticket:   str   = ""

    last_profit:    float = 0.0
    open_time:      str   = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    last_update:    str   = ""

    @property
    def risk(self) -> float:
        return abs(self.entry_price - self.initial_sl)


# ══════════════════════════════════════════════════════════════════════════════
# TRADE MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class TradeManager:
    """
    Manages all open trades.  Call .tick() every scan cycle.
    """

    def __init__(
        self,
        active_trades: dict,                # ticket_str → dict (from trader_state)
        send_command:  Callable[[str], str], # fn(cmd_string) → result
        data_loader:   Callable[[], dict],   # fn() → full MT5 data dict
        paper_mode:    bool = True,
        memory=None,
    ):
        self._raw       = active_trades      # live reference (mutated in place)
        self._cmd       = send_command
        self._load      = data_loader
        self._paper     = paper_mode
        self._memory    = memory
        self._trades: dict[str, ActiveTrade] = {}
        self._sync_from_raw()

    # ── Sync ─────────────────────────────────────────────────────────────────

    def _sync_from_raw(self):
        """Rebuild ActiveTrade objects from the raw dict."""
        for tk, raw in self._raw.items():
            if tk not in self._trades:
                try:
                    self._trades[tk] = ActiveTrade(
                        ticket      = tk,
                        symbol      = raw.get("symbol", ""),
                        direction   = raw.get("direction", "BUY"),
                        entry_price = raw.get("entry", 0.0),
                        initial_sl  = raw.get("sl", raw.get("initial_sl", 0.0)),
                        current_sl  = raw.get("sl", raw.get("current_sl", 0.0)),
                        tp1         = raw.get("tp1", 0.0),
                        tp2         = raw.get("tp2", 0.0),
                        tp3         = raw.get("tp3", 0.0),
                        volume      = raw.get("volume_original", raw.get("volume", 0.01)),
                        risk_usd    = raw.get("risk_usd", 0.0),
                        entry_type  = raw.get("entry_type", ""),
                        memory_id   = raw.get("memory_trade_id", ""),
                        tp1_taken   = raw.get("tp1_taken", False),
                        tp2_taken   = raw.get("tp2_taken", False),
                        be_triggered = raw.get("be_triggered", False),
                        scaled_in   = raw.get("scaled_in", False),
                        last_profit = raw.get("last_profit", 0.0),
                    )
                except Exception as e:
                    log.error(f"Trade sync error {tk}: {e}")

    def _push_to_raw(self, trade: ActiveTrade):
        """Write back to the state dict (persisted by auto_trader save_state)."""
        if trade.ticket not in self._raw:
            return
        self._raw[trade.ticket].update({
            "sl":            trade.current_sl,
            "tp1_taken":     trade.tp1_taken,
            "tp2_taken":     trade.tp2_taken,
            "be_triggered":  trade.be_triggered,
            "scaled_in":     trade.scaled_in,
            "last_profit":   trade.last_profit,
            "current_sl":    trade.current_sl,
            "initial_sl":    trade.initial_sl,
            "last_update":   datetime.now(timezone.utc).isoformat(),
        })

    # ── Main tick ─────────────────────────────────────────────────────────────

    def tick(self) -> list[str]:
        """
        Called every scan cycle.  Returns list of log messages.
        Mutates self._raw (which is the state dict in auto_trader).
        """
        data = self._load()
        if not data:
            return ["[TradeManager] No data available"]

        positions = {str(p.get("ticket")): p for p in data.get("positions", [])}
        charts    = data.get("charts", {})
        history   = {str(h.get("ticket", "")): h
                     for h in data.get("history", []) if isinstance(h, dict)}

        # Sync newly added tickets from raw
        self._sync_from_raw()

        msgs = []

        # ── Detect closed trades ──────────────────────────────────────────────
        closed = [tk for tk in list(self._trades.keys()) if tk not in positions]
        for tk in closed:
            trade = self._trades.pop(tk)
            self._raw.pop(tk, None)
            profit = history.get(tk, {}).get("profit", trade.last_profit)
            r_mult = (profit / trade.risk_usd) if trade.risk_usd > 0 else 0.0

            status = "WIN" if profit > 0.01 else ("LOSS" if profit < -0.01 else "BREAKEVEN")
            msg = (f"[CLOSED {status}] {trade.symbol} {trade.direction} "
                   f"P&L=${profit:+.2f} R={r_mult:+.2f}")
            msgs.append(msg)
            log.info(msg)

            if self._memory and trade.memory_id:
                try:
                    close_price = history.get(tk, {}).get("price", trade.entry_price)
                    tp_hit = self._detect_tp_level(trade, close_price)
                    self._memory.record_close(
                        trade_id   = trade.memory_id,
                        close_price = close_price,
                        profit_usd = profit,
                        r_multiple = r_mult,
                        tp_level_hit = tp_hit,
                        close_reason = f"Auto-closed | {status}",
                    )
                except Exception as e:
                    log.warning(f"Memory close error: {e}")

        # ── Manage open trades ────────────────────────────────────────────────
        for tk, pos in positions.items():
            if not self._paper and pos.get("magic", 0) != 20250411:
                continue
            if tk not in self._trades:
                continue

            trade   = self._trades[tk]
            sym_data = charts.get(trade.symbol, {})
            cur_price = float(pos.get("current_price", 0.0))
            cur_sl    = float(pos.get("sl", trade.current_sl))
            volume    = float(pos.get("volume", trade.volume))
            profit    = float(pos.get("profit", 0.0))
            trade.last_profit = profit

            if cur_price <= 0 or trade.risk <= 0:
                continue

            # Compute profit in R
            if trade.direction == "BUY":
                profit_r = (cur_price - trade.entry_price) / trade.risk
            else:
                profit_r = (trade.entry_price - cur_price) / trade.risk

            # ── Partial take-profits ──────────────────────────────────────
            min_lot = sym_data.get("min_lot", 0.01)

            if not trade.tp1_taken and trade.tp1 > 0:
                hit = (trade.direction == "BUY"  and cur_price >= trade.tp1) or \
                      (trade.direction == "SELL" and cur_price <= trade.tp1)
                if hit:
                    vol_close = max(min_lot, round(volume * 0.50, 2))
                    result = self._close_partial(tk, vol_close)
                    trade.tp1_taken = True
                    msg = (f"[TP1] {trade.symbol} {trade.direction} "
                           f"closed 50% ({vol_close:.2f} lots) @ {cur_price:.5g} | {result}")
                    msgs.append(msg); log.info(msg)
                    self._push_to_raw(trade)

            if trade.tp1_taken and not trade.tp2_taken and trade.tp2 > 0:
                hit = (trade.direction == "BUY"  and cur_price >= trade.tp2) or \
                      (trade.direction == "SELL" and cur_price <= trade.tp2)
                if hit:
                    vol_close = max(min_lot, round(volume * 0.30, 2))
                    result = self._close_partial(tk, vol_close)
                    trade.tp2_taken = True
                    msg = (f"[TP2] {trade.symbol} {trade.direction} "
                           f"closed 30% ({vol_close:.2f} lots) @ {cur_price:.5g} | {result}")
                    msgs.append(msg); log.info(msg)
                    self._push_to_raw(trade)

            # ── Trailing SL (NEVER lets winner become loser) ──────────────
            m15_bars = parse_bars(sym_data.get("M15", [])) if _DTF_AVAILABLE else []
            atr_m15  = calc_atr(m15_bars, 14) if (m15_bars and _DTF_AVAILABLE) else trade.risk * 0.5

            new_sl, trail_reason = compute_trailing_sl(
                entry      = trade.entry_price,
                current    = cur_price,
                current_sl = trade.current_sl,
                direction  = trade.direction,
                risk       = trade.risk,
                m15_bars   = m15_bars,
                atr        = atr_m15,
            ) if _DTF_AVAILABLE else self._fallback_trail(
                trade, cur_price, atr_m15
            )

            # Only update if SL improves (never widen)
            sl_improved = (
                (trade.direction == "BUY"  and new_sl > trade.current_sl + trade.risk * 0.02) or
                (trade.direction == "SELL" and new_sl < trade.current_sl - trade.risk * 0.02)
            )

            if sl_improved and trail_reason:
                min_move = max(trade.risk * 0.05,
                               sym_data.get("point", 0.0001) * 30)
                if abs(new_sl - cur_sl) >= min_move:
                    result = self._modify_sl(tk, new_sl)
                    trade.current_sl = new_sl
                    if new_sl >= trade.entry_price and trade.direction == "BUY":
                        trade.be_triggered = True
                    if new_sl <= trade.entry_price and trade.direction == "SELL":
                        trade.be_triggered = True
                    msg = (f"[TRAIL] {trade.symbol} SL "
                           f"{cur_sl:.5g} → {new_sl:.5g} "
                           f"({trail_reason}) | {result}")
                    msgs.append(msg); log.info(msg)
                    self._push_to_raw(trade)

            # ── Close runner on opposing H1 BOS ──────────────────────────
            if trade.tp2_taken and trade.tp3 > 0:
                h1_bars = parse_bars(sym_data.get("H1", [])) if _DTF_AVAILABLE else []
                if h1_bars and _DTF_AVAILABLE:
                    h4_struct = _h4_structure(h1_bars)
                    opposing = (
                        (trade.direction == "BUY"  and h4_struct == "BOS_BEAR") or
                        (trade.direction == "SELL" and h4_struct == "BOS_BULL")
                    )
                    if opposing:
                        result = self._close_full(tk)
                        msg = (f"[RUNNER CLOSE] {trade.symbol} — opposing H1 BOS "
                               f"({h4_struct}) — runner closed | {result}")
                        msgs.append(msg); log.warning(msg)

            # ── Check for opposing FVG / OB against runner ────────────────
            if trade.tp2_taken and not trade.tp2_taken and _DTF_AVAILABLE:
                m15_bars_check = parse_bars(sym_data.get("M15", []))
                if m15_bars_check:
                    opp_dir = "SELL" if trade.direction == "BUY" else "BUY"
                    opp_obs = find_ob_zones(m15_bars_check, opp_dir, search=5)
                    if opp_obs:
                        ob = opp_obs[0]
                        at_ob = (
                            (trade.direction == "BUY"  and cur_price >= ob.low * 0.999) or
                            (trade.direction == "SELL" and cur_price <= ob.high * 1.001)
                        )
                        if at_ob:
                            result = self._close_full(tk)
                            msg = (f"[EXIT OB] {trade.symbol} {trade.direction} "
                                   f"— runner at opposing OB {ob.low:.5g}–{ob.high:.5g} | {result}")
                            msgs.append(msg); log.info(msg)

        return msgs

    # ── Scale-in ──────────────────────────────────────────────────────────────

    def check_scale_in(self, data: dict, equity: float) -> list[str]:
        """
        After TP1 hit and push momentum confirmed on M15 → add 50% position.
        Requires: 1R profit, TP1 taken, M15 push, no opposing H1 BOS.
        """
        if not _DTF_AVAILABLE:
            return []

        msgs  = []
        charts = data.get("charts", {})
        positions = {str(p.get("ticket")): p for p in data.get("positions", [])}

        for tk, trade in self._trades.items():
            if trade.scaled_in or not trade.tp1_taken:
                continue
            pos = positions.get(tk)
            if not pos:
                continue

            cur_price = float(pos.get("current_price", 0.0))
            sym_data  = charts.get(trade.symbol, {})
            m15_bars  = parse_bars(sym_data.get("M15", []))
            h1_bars   = parse_bars(sym_data.get("H1",  []))

            if not m15_bars or trade.risk <= 0:
                continue

            profit_r = (
                (cur_price - trade.entry_price) / trade.risk
                if trade.direction == "BUY"
                else (trade.entry_price - cur_price) / trade.risk
            )
            if profit_r < 1.0:
                continue

            # Check M15 push phase
            from omni_dual_tf_engine import detect_push_exhaustion_simple
            push = detect_push_exhaustion_simple(m15_bars[:6], trade.direction)
            if not push:
                continue

            # No opposing H1 BOS
            if h1_bars:
                h4_struct = _h4_structure(h1_bars)
                opposing = (
                    (trade.direction == "BUY"  and h4_struct == "BOS_BEAR") or
                    (trade.direction == "SELL" and h4_struct == "BOS_BULL")
                )
                if opposing:
                    continue

            # Calculate scale-in lot
            min_lot = sym_data.get("min_lot", 0.01)
            scale_vol = max(min_lot, round(trade.volume * 0.50, 2))
            scale_sl  = trade.current_sl  # Already at BE or better
            rem_to_tp3 = abs(trade.tp3 - cur_price)
            if trade.direction == "BUY":
                scale_tp = round(cur_price + rem_to_tp3 * 1.5, 5)
            else:
                scale_tp = round(cur_price - rem_to_tp3 * 1.5, 5)

            order_type = "BUY" if trade.direction == "BUY" else "SELL"
            cmd = f"OPEN|{trade.symbol}|{order_type}|{cur_price:.5f}|{scale_sl:.5f}|{scale_tp:.5f}|{scale_vol:.2f}|OMNI_SCALE_{tk}"
            result = self._cmd(cmd)

            msg = (f"[SCALE-IN] {trade.symbol} {trade.direction} "
                   f"+{scale_vol} lots @ {cur_price:.5g} | {result}")
            msgs.append(msg); log.info(msg)

            trade.scaled_in = True
            self._push_to_raw(trade)

        return msgs

    # ── Command wrappers ──────────────────────────────────────────────────────

    def _close_partial(self, ticket: str, volume: float) -> str:
        if self._paper:
            return f"PAPER|partial {volume:.2f} lots"
        cmd = f"CLOSE|{ticket}|||||{volume:.2f}|"
        return self._cmd(cmd)

    def _close_full(self, ticket: str) -> str:
        if self._paper:
            return "PAPER|full close"
        cmd = f"CLOSE|{ticket}|||||0|"
        return self._cmd(cmd)

    def _modify_sl(self, ticket: str, new_sl: float) -> str:
        if self._paper:
            return f"PAPER|SL→{new_sl:.5g}"
        trade = self._trades.get(ticket)
        tp    = trade.tp3 if trade else 0
        cmd   = f"MODIFY|{ticket}|||{new_sl:.5f}|{tp:.5f}||"
        return self._cmd(cmd)

    # ── Fallback trailing (no DTF engine available) ───────────────────────────

    def _fallback_trail(
        self, trade: ActiveTrade, cur_price: float, atr: float
    ) -> tuple[float, str]:
        risk = trade.risk
        entry = trade.entry_price
        cur_sl = trade.current_sl

        if trade.direction == "BUY":
            profit_r = (cur_price - entry) / risk
            if profit_r >= 2.0:
                return max(cur_sl, entry + risk), "2R fallback trail"
            if profit_r >= 1.0:
                return max(cur_sl, entry), "1R BE fallback"
        else:
            profit_r = (entry - cur_price) / risk
            if profit_r >= 2.0:
                return min(cur_sl, entry - risk), "2R fallback trail"
            if profit_r >= 1.0:
                return min(cur_sl, entry), "1R BE fallback"

        return cur_sl, ""

    # ── Utility ───────────────────────────────────────────────────────────────

    def _detect_tp_level(self, trade: ActiveTrade, close_price: float) -> str:
        if trade.tp3 and abs(close_price - trade.tp3) < trade.risk * 0.3:
            return "TP3"
        if trade.tp2 and abs(close_price - trade.tp2) < trade.risk * 0.3:
            return "TP2"
        if trade.tp1 and abs(close_price - trade.tp1) < trade.risk * 0.3:
            return "TP1"
        profit = (
            (close_price - trade.entry_price) if trade.direction == "BUY"
            else (trade.entry_price - close_price)
        )
        if profit < 0:
            return "SL"
        return "MANUAL"


# ── Push/exhaustion simple version (avoids full import cycle) ─────────────────
# Also add this to omni_dual_tf_engine.py if not present

def detect_push_exhaustion_simple(bars, direction: str, lookback: int = 5) -> bool:
    """Returns True if bars show PUSH momentum in given direction."""
    if len(bars) < lookback:
        return False
    recent = bars[:lookback]
    if direction == "BUY":
        bull_count = sum(1 for b in recent if b.c > b.o)
        if bull_count < lookback - 1:
            return False
        bodies = [b.body for b in recent]
        # Bodies growing = push
        return bodies[0] >= bodies[-1] * 0.7  # Recent bodies not shrinking
    else:
        bear_count = sum(1 for b in recent if b.c < b.o)
        if bear_count < lookback - 1:
            return False
        bodies = [b.body for b in recent]
        return bodies[0] >= bodies[-1] * 0.7
