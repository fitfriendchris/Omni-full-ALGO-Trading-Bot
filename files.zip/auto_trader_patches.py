"""
auto_trader_patches.py
======================
COPY-PASTE GUIDE: How to wire the new modules into your existing auto_trader.py

This file is NOT standalone — it shows the exact code changes to make in
auto_trader.py to enable:

  ✅ Dual-TF ICT engine (D1/H4 bias + M15/M5 precision entries)
  ✅ Enhanced trailing stops (never let a winner become a loser)
  ✅ Automatic log cleanup (no more disk bloat)
  ✅ Autonomous restart resilience

──────────────────────────────────────────────────────────────────────
PATCH 1 — Top of auto_trader.py (after existing imports)
──────────────────────────────────────────────────────────────────────
"""

# ── PATCH 1: New imports ─────────────────────────────────────────────────────
# Add these lines after the existing imports in auto_trader.py:

_PATCH_1_IMPORTS = """
# ── Enhanced ICT modules ──────────────────────────────────────────────────────
try:
    from omni_dual_tf_engine import scan_all_symbols_dual, DualTFSetup
    from trade_manager_enhanced import TradeManager
    from log_cleanup import install as install_cleanup, setup_rotating_logger
    _DUAL_TF = True
    log.info("✓ Dual-TF ICT engine loaded")
except ImportError as _e:
    _DUAL_TF = False
    log.warning(f"Dual-TF engine not available ({_e}) — using legacy scanner")
"""

# ── PATCH 2: Replace logging setup ──────────────────────────────────────────
# Replace the existing logging.basicConfig block with:

_PATCH_2_LOGGING = """
# ── Logging with auto-rotation ────────────────────────────────────────────────
try:
    from log_cleanup import setup_rotating_logger
    log = setup_rotating_logger("OMNI", LOG_PATH,
                                max_mb=5, backups=5, level=logging.INFO)
except ImportError:
    # Fallback to rotating handler manually
    _file_handler = logging.handlers.RotatingFileHandler(
        LOG_PATH, maxBytes=5*1024*1024, backupCount=5, encoding="utf-8"
    )
    _file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    _stream_handler = logging.StreamHandler(sys.stdout)
    _stream_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logging.basicConfig(level=logging.INFO, handlers=[_file_handler, _stream_handler])
    log = logging.getLogger("OMNI")
"""

# ── PATCH 3: Main loop — replace scan + trade management ────────────────────
# In the main() function, inside the while True loop,
# replace the existing scan and manage section with:

_PATCH_3_MAIN_LOOP = """
# ── Initialize TradeManager (once, outside the loop) ─────────────────────────
# In main() before the while True loop:

trade_mgr = None
if _DUAL_TF:
    trade_mgr = TradeManager(
        active_trades = state.active_trades,
        send_command  = send_command,
        data_loader   = load_mt5_data,
        paper_mode    = PAPER_MODE,
        memory        = memory,
    )
    log.info("TradeManager initialized (dual-TF mode)")

# Install log cleanup (runs every 30 min in background)
if _DUAL_TF:
    from log_cleanup import install as install_cleanup
    install_cleanup(str(SCRIPT_DIR), interval=1800)
    log.info("LogCleanup started")

# ─────────────────────────────────────────────────────────────────────────────
# Inside the while True loop, replace manage_open_trades() + scan block:
# ─────────────────────────────────────────────────────────────────────────────

            # ── Manage open trades with enhanced trailing stops ────────────
            if trade_mgr:
                msgs = trade_mgr.tick()
                for m in msgs:
                    log.info(m)
                # Scale-in check
                if len(positions) > 0:
                    scale_msgs = trade_mgr.check_scale_in(data, equity)
                    for m in scale_msgs:
                        log.info(m)
            else:
                # Fallback to legacy trade management
                manage_open_trades(state, data, memory=memory)

            # ── Scan for new setups (Dual-TF preferred) ───────────────────
            all_setups_raw = []

            if _DUAL_TF and can_trade:
                try:
                    dual_setups = scan_all_symbols_dual(TRADE_SYMBOLS)
                    # Convert DualTFSetup to ICTSetup-compatible for execute_setup
                    all_setups_raw = [_convert_dual_setup(s) for s in dual_setups[:20]]
                    log.debug(f"Dual-TF scan: {len(all_setups_raw)} setups found")
                except Exception as e:
                    log.error(f"Dual-TF scan error: {e}")
                    all_setups_raw = ict.scan_all_primary_symbols()
            else:
                # Fallback: legacy scanner
                all_setups_raw = ict.scan_all_primary_symbols() if can_trade else []
"""

# ── PATCH 4: Dual-TF setup converter ─────────────────────────────────────────
# Add this function near the bottom of auto_trader.py, before main():

_PATCH_4_CONVERTER = """
def _convert_dual_setup(ds) -> "ICTSetup":
    \"\"\"
    Convert DualTFSetup → ICTSetup so execute_setup() works without changes.
    \"\"\"
    from ict_precision import ICTSetup, ConfluenceScore
    cs = ConfluenceScore(
        htf_bias_aligned  = ds.htf.d1_bias == ds.direction,
        amd_phase_aligned = ds.amd_phase in ("MANIPULATION", "DISTRIBUTION"),
        killzone_active   = "KILL" in " ".join(ds.reasons),
        liquidity_swept   = ds.sweep_level > 0,
        fvg_in_ote        = ds.ltf.fvg_entry,
        mss_confirmed     = ds.ltf.mss_confirmed,
        smt_divergence    = False,
    )

    return ICTSetup(
        symbol      = ds.symbol,
        direction   = ds.direction,
        entry_type  = ds.setup_type,
        entry_price = ds.entry,
        sl_price    = ds.sl,
        tp1_price   = ds.tp1,
        tp2_price   = ds.tp2,
        tp3_price   = ds.tp3,
        confidence  = ds.confidence,
        reasons     = ds.reasons,
        session     = ds.session,
        amd_phase   = ds.amd_phase,
        rr_ratio    = ds.rr_ratio,
        tf_bias     = ds.htf.d1_bias,
        invalidation = ds.sl * (0.998 if ds.direction == "BUY" else 1.002),
        confluence  = cs,
        grade       = cs.grade,
    )
"""

# ── PATCH 5: config.py additions ─────────────────────────────────────────────
# Add to config.py _Config class (these enable dual-TF features):

_PATCH_5_CONFIG = """
    # ── Dual-TF ICT Engine settings ──────────────────────────────────────────
    USE_DUAL_TF_ENGINE:     bool  = _getbool("OMNI_USE_DUAL_TF", "use_dual_tf", True)
    MIN_DUAL_TF_CONFIDENCE: int   = _getint("OMNI_DUAL_TF_CONF", "dual_tf_min_conf", 55)

    # ── Trailing stop tiers (in R multiples) ─────────────────────────────────
    TRAIL_BE_R:       float = 1.0   # Move SL to BE at this R
    TRAIL_LOCK_05R:   float = 1.5   # Lock in 0.5R at this R
    TRAIL_LOCK_1R:    float = 2.0   # Lock in 1R at this R
    TRAIL_TIGHT_R:    float = 3.0   # Start structural trail at this R

    # ── Log cleanup ───────────────────────────────────────────────────────────
    LOG_CLEANUP_INTERVAL_SECS: int  = _getint("OMNI_LOG_CLEANUP", "log_cleanup_secs", 1800)
    MAX_LOG_MB:                int  = _getint("OMNI_MAX_LOG_MB",  "max_log_mb", 5)
    MAX_ROTATIONS:             int  = _getint("OMNI_MAX_ROTATIONS","max_log_rotations", 5)
    MAX_MEMORY_TRADES:         int  = _getint("OMNI_MAX_TRADES_STORED","max_memory_trades", 500)
    MAX_JOURNAL_DAYS:          int  = _getint("OMNI_MAX_JOURNAL_DAYS", "max_journal_days", 30)
"""

# ── SUMMARY OF CHANGES ───────────────────────────────────────────────────────
print("""
╔══════════════════════════════════════════════════════════════════╗
║  OMNI INTEGRATION PATCHES — SUMMARY                             ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  FILES TO ADD to your project directory:                         ║
║    ✅ omni_dual_tf_engine.py   (dual-TF ICT analysis)            ║
║    ✅ trade_manager_enhanced.py (trailing stops + partials)       ║
║    ✅ log_cleanup.py           (log rotation + cleanup)           ║
║                                                                  ║
║  CHANGES TO auto_trader.py:                                      ║
║    • Patch 1: New imports at top                                  ║
║    • Patch 2: Replace logging setup with rotating logger         ║
║    • Patch 3: Replace scan + manage block in main loop           ║
║    • Patch 4: Add _convert_dual_setup() function                 ║
║                                                                  ║
║  CHANGES TO config.py:                                           ║
║    • Patch 5: Add dual-TF + cleanup settings to _Config          ║
║                                                                  ║
║  VPS DEPLOYMENT:                                                 ║
║    $ scp -r ./omni-ict/ root@YOUR_VPS:/opt/omni-ict/             ║
║    $ ssh root@YOUR_VPS "bash /opt/omni-ict/deploy_vps.sh"        ║
║                                                                  ║
║  The bot will then run 24/7, restart on crash,                   ║
║  and never require you to manually start anything.               ║
╚══════════════════════════════════════════════════════════════════╝
""")
