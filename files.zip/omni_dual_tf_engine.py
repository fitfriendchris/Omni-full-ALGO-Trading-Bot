"""
omni_dual_tf_engine.py  —  OMNI ICT Dual-Timeframe Analysis Engine v3.0
=========================================================================
TRUE top-down ICT cascade:

  D1  →  Overall bias + draw-on-liquidity targets (PDH/PDL, major OB/FVG)
  H4  →  Structure confirmation + H4 OBs/FVGs to target
  H1  →  Setup zone (where price is likely to react)
  M15 →  Entry trigger  (MSS / CHoCH after liquidity sweep)
  M5  →  Precision entry (FVG or OB for the limit order)

Replaces ict_precision.py as the primary signal generator.
Drop-in: from omni_dual_tf_engine import DualTFScanner, scan_symbol_dual

PHILOSOPHY:
  • HTF defines WHERE price is going (draw on liquidity)
  • LTF defines WHEN and at WHAT EXACT PRICE to get in
  • Entry is ONLY taken on a M5/M15 FVG AFTER a sweep + MSS
  • SL is STRUCTURAL: below the M15 swing low that preceded the MSS (for longs)
  • TP1 = nearest M15/H1 liquidity above (not a fixed R multiple)
  • TP2 = H4 target
  • TP3 = D1 draw-on-liquidity
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

log = logging.getLogger("DualTF")

try:
    from config import cfg
    _JSON_PATH = cfg.JSON_PATH
except ImportError:
    _JSON_PATH = ""


# ══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Bar:
    time: str
    o: float; h: float; l: float; c: float; v: int = 0

    @property
    def bullish(self)  -> bool: return self.c > self.o
    @property
    def bearish(self)  -> bool: return self.c < self.o
    @property
    def body(self)     -> float: return abs(self.c - self.o)
    @property
    def range(self)    -> float: return max(self.h - self.l, 1e-10)
    @property
    def body_pct(self) -> float: return self.body / self.range
    @property
    def upper_wick(self) -> float: return self.h - max(self.o, self.c)
    @property
    def lower_wick(self) -> float: return min(self.o, self.c) - self.l


@dataclass
class OBZone:
    low: float; high: float; direction: str   # "BULL" | "BEAR"
    age_bars: int = 0
    mitigation_pct: float = 0.0              # 0 = untouched, 1 = fully mitigated


@dataclass
class FVGZone:
    low: float; high: float; ce: float       # CE = 50% of gap
    direction: str                            # "BULL" | "BEAR"
    age_bars: int = 0
    filled: bool = False


@dataclass
class LiquidityLevel:
    price: float
    level_type: str   # EQH | EQL | PDH | PDL | PWH | PWL | SwingH | SwingL
    sweeps: int = 0
    is_swept: bool = False


@dataclass
class HTFContext:
    """D1 + H4 context — the narrative"""
    d1_bias:      str = "NEUTRAL"  # BULLISH | BEARISH | NEUTRAL
    h4_structure: str = "RANGING"  # BOS_BULL | BOS_BEAR | RANGING
    draw_target:  float = 0.0      # Price level price is delivering to (liq target)
    draw_type:    str = ""         # BSL (buy-side liq) | SSL (sell-side liq)
    major_ob:     Optional[OBZone] = None
    major_fvg:    Optional[FVGZone] = None
    in_premium:   bool = False     # Price > equilibrium
    in_discount:  bool = False     # Price < equilibrium
    equilibrium:  float = 0.0
    phase:        str = "ACCUMULATION"  # AMD phase


@dataclass
class LTFEntry:
    """M15 + M5 precision entry package"""
    confirmed:    bool = False
    entry:        float = 0.0
    sl:           float = 0.0      # STRUCTURAL SL — below/above the swept swing
    tp1:          float = 0.0      # Nearest H1 liquidity
    tp2:          float = 0.0      # H4 target
    tp3:          float = 0.0      # D1 draw-on-liquidity
    trigger_tf:   str = ""         # "M5" | "M15"
    setup_type:   str = ""         # SWEEP_REVERSAL | IOFED | OB_RETEST | SILVER_BULLET
    sweep_level:  float = 0.0      # Liquidity level that was swept
    mss_confirmed: bool = False
    fvg_entry:    bool = False      # Using FVG for entry (tightest)
    ob_entry:     bool = False      # Using OB for entry
    reasons:      list = field(default_factory=list)
    rr_ratio:     float = 0.0
    confidence:   int = 0


@dataclass
class DualTFSetup:
    """Final tradeable setup with full context"""
    symbol:       str
    direction:    str              # BUY | SELL
    entry:        float
    sl:           float
    tp1:          float
    tp2:          float
    tp3:          float
    rr_ratio:     float
    confidence:   int
    setup_type:   str
    trigger_tf:   str
    htf:          HTFContext = field(default_factory=HTFContext)
    ltf:          LTFEntry   = field(default_factory=LTFEntry)
    session:      str = ""
    amd_phase:    str = ""
    sweep_level:  float = 0.0
    reasons:      list = field(default_factory=list)

    # Trade management helpers (set after entry)
    be_triggered: bool = False     # Break-even SL placed
    trail_sl:     float = 0.0      # Current trailing SL
    tp1_taken:    bool = False
    tp2_taken:    bool = False


# ══════════════════════════════════════════════════════════════════════════════
# BAR PARSING & UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

def parse_bars(raw: list) -> list[Bar]:
    bars = []
    for b in raw:
        try:
            bars.append(Bar(b["t"], float(b["o"]), float(b["h"]),
                            float(b["l"]), float(b["c"]), int(b.get("v", 0))))
        except (KeyError, ValueError):
            pass
    return bars


def calc_atr(bars: list[Bar], period: int = 14) -> float:
    if len(bars) < 2:
        return 0.0
    trs = []
    for i in range(min(period, len(bars) - 1)):
        tr = max(bars[i].h - bars[i].l,
                 abs(bars[i].h - bars[i + 1].c),
                 abs(bars[i].l - bars[i + 1].c))
        trs.append(tr)
    return sum(trs) / len(trs) if trs else 0.0


def swing_highs(bars: list[Bar], lookback: int = 3) -> list[tuple[int, float]]:
    out = []
    for i in range(lookback, len(bars) - lookback):
        if all(bars[i].h >= bars[i-j].h and bars[i].h >= bars[i+j].h
               for j in range(1, lookback + 1)):
            out.append((i, bars[i].h))
    return out


def swing_lows(bars: list[Bar], lookback: int = 3) -> list[tuple[int, float]]:
    out = []
    for i in range(lookback, len(bars) - lookback):
        if all(bars[i].l <= bars[i-j].l and bars[i].l <= bars[i+j].l
               for j in range(1, lookback + 1)):
            out.append((i, bars[i].l))
    return out


def equal_highs(bars: list[Bar], tol: float = 0.002) -> list[float]:
    hs = [b.h for b in bars]
    result = []
    for h in hs:
        if sum(1 for x in hs if abs(x - h) / h < tol) >= 2:
            if not any(abs(h - r) / h < tol for r in result):
                result.append(h)
    return sorted(result, reverse=True)


def equal_lows(bars: list[Bar], tol: float = 0.002) -> list[float]:
    ls = [b.l for b in bars if b.l > 0]
    result = []
    for l in ls:
        if sum(1 for x in ls if abs(x - l) / l < tol) >= 2:
            if not any(abs(l - r) / l < tol for r in result):
                result.append(l)
    return sorted(result)


# ══════════════════════════════════════════════════════════════════════════════
# ICT PATTERN DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def find_ob_zones(bars: list[Bar], direction: str,
                  search: int = 20, min_impulse: float = 0.55) -> list[OBZone]:
    """
    Find Order Blocks.
    BULL OB: last bearish candle before a bullish impulse that left an FVG.
    BEAR OB: last bullish candle before a bearish impulse that left an FVG.
    Bars are newest-first (MT5 format).
    """
    zones = []
    bars_asc = list(reversed(bars[:search + 2]))  # oldest first
    n = len(bars_asc)

    for i in range(1, n - 1):
        b, bn = bars_asc[i], bars_asc[i + 1]
        if bn.range <= 0:
            continue
        impulse = bn.body / bn.range

        if direction == "BULL" and b.bearish and bn.bullish and impulse >= min_impulse:
            # Confirm FVG left by the impulse candle
            if i + 2 < n and bars_asc[i - 1].h < bars_asc[i + 1].l:
                zones.append(OBZone(low=b.l, high=b.h, direction="BULL",
                                    age_bars=n - 1 - i))
        elif direction == "BEAR" and b.bullish and bn.bearish and impulse >= min_impulse:
            if i + 2 < n and bars_asc[i - 1].l > bars_asc[i + 1].h:
                zones.append(OBZone(low=b.l, high=b.h, direction="BEAR",
                                    age_bars=n - 1 - i))

    # Remove mitigated (price closed inside or through the OB)
    cur = bars[0].c
    active = []
    for z in zones:
        if z.direction == "BULL" and cur < z.high * 1.005:
            active.append(z)
        elif z.direction == "BEAR" and cur > z.low * 0.995:
            active.append(z)
    return active


def find_fvgs(bars: list[Bar], direction: str,
              search: int = 15) -> list[FVGZone]:
    """
    Fair Value Gaps.
    BULL FVG: bars[i].low > bars[i+2].high   (gap up — imbalance)
    BEAR FVG: bars[i].high < bars[i+2].low   (gap down — imbalance)
    Bars newest-first.
    """
    zones = []
    cur = bars[0].c if bars else 0

    for i in range(search):
        if i + 2 >= len(bars):
            break
        b0, b2 = bars[i], bars[i + 2]

        if direction == "BULL" and b0.l > b2.h:
            ce = (b0.l + b2.h) / 2
            filled = cur < b2.h  # price dropped below FVG
            zones.append(FVGZone(low=b2.h, high=b0.l, ce=ce,
                                 direction="BULL", age_bars=i, filled=filled))
        elif direction == "BEAR" and b0.h < b2.l:
            ce = (b0.h + b2.l) / 2
            filled = cur > b2.l
            zones.append(FVGZone(low=b0.h, high=b2.l, ce=ce,
                                 direction="BEAR", age_bars=i, filled=filled))

    return [z for z in zones if not z.filled]


def detect_sweep(bars: list[Bar], level: float, direction: str,
                 tol: float = 0.0015) -> bool:
    """
    Detect liquidity sweep.
    For BULL sweep of equal-lows: bar spiked BELOW level then CLOSED back above.
    For BEAR sweep of equal-highs: bar spiked ABOVE level then CLOSED back below.
    Check the last 3 bars.
    """
    for b in bars[:3]:
        if direction == "BULL":
            if b.l < level * (1 - tol) and b.c > level:
                return True
        else:
            if b.h > level * (1 + tol) and b.c < level:
                return True
    return False


def detect_mss(bars: list[Bar], direction: str, lookback: int = 12) -> bool:
    """
    Market Structure Shift (MSS) on the given TF.
    BUY  MSS: price made a lower-low, then CLOSED above the last swing HIGH before that low.
    SELL MSS: price made a higher-high, then CLOSED below the last swing LOW before that high.
    """
    recent = bars[:lookback]
    if direction == "BUY":
        lows  = swing_lows(recent,  lookback=2)
        highs = swing_highs(recent, lookback=2)
        if not lows or not highs:
            return False
        last_low_idx = lows[0][0]
        # Pivot high must have formed BEFORE (higher index = older in newest-first)
        pivots = [(i, p) for i, p in highs if i > last_low_idx]
        if not pivots:
            return False
        pivot_h = pivots[0][1]
        return recent[0].c > pivot_h

    else:  # SELL
        highs = swing_highs(recent, lookback=2)
        lows  = swing_lows(recent,  lookback=2)
        if not highs or not lows:
            return False
        last_high_idx = highs[0][0]
        pivots = [(i, p) for i, p in lows if i > last_high_idx]
        if not pivots:
            return False
        pivot_l = pivots[0][1]
        return recent[0].c < pivot_l


def structural_sl(bars: list[Bar], entry: float, direction: str,
                  zone_edge: float) -> float:
    """
    ICT structural SL: below the SWING LOW that preceded the bullish MSS (for longs),
    or above the swing HIGH that preceded the bearish MSS (for shorts).
    Falls back to zone_edge ± 1.2× ATR with a hard minimum of 0.5× ATR.
    """
    atr = calc_atr(bars, 14)
    buf = atr * 0.12

    if direction == "BUY":
        # Nearest swing low BELOW the zone edge
        candidates = sorted(
            [p for _, p in swing_lows(bars, lookback=2) if p < zone_edge],
            reverse=True
        )
        sl = (candidates[0] - buf) if candidates else (zone_edge - atr * 1.2)
        # Hard floor: SL must be at least 0.5× ATR below entry
        if entry - sl < atr * 0.5:
            sl = entry - atr * 0.5
        return sl
    else:
        candidates = sorted(
            [p for _, p in swing_highs(bars, lookback=2) if p > zone_edge]
        )
        sl = (candidates[0] + buf) if candidates else (zone_edge + atr * 1.2)
        if sl - entry < atr * 0.5:
            sl = entry + atr * 0.5
        return sl


# ══════════════════════════════════════════════════════════════════════════════
# HTF CONTEXT BUILDER  (D1 + H4)
# ══════════════════════════════════════════════════════════════════════════════

def _d1_bias(d1_bars: list[Bar]) -> str:
    if len(d1_bars) < 6:
        return "NEUTRAL"
    recent = d1_bars[:10]
    half = max(len(recent) // 2, 1)
    avg_h1 = sum(b.h for b in recent[:half]) / half
    avg_h2 = sum(b.h for b in recent[half:]) / half
    avg_l1 = sum(b.l for b in recent[:half]) / half
    avg_l2 = sum(b.l for b in recent[half:]) / half
    if avg_h1 > avg_h2 and avg_l1 > avg_l2:
        return "BULLISH"
    if avg_h1 < avg_h2 and avg_l1 < avg_l2:
        return "BEARISH"
    return "NEUTRAL"


def _h4_structure(h4_bars: list[Bar]) -> str:
    if len(h4_bars) < 10:
        return "RANGING"
    shs = swing_highs(h4_bars, lookback=3)
    sls = swing_lows(h4_bars,  lookback=3)
    cur = h4_bars[0].c
    if shs and cur > shs[0][1]:
        return "BOS_BULL"
    if sls and cur < sls[0][1]:
        return "BOS_BEAR"
    return "RANGING"


def _amd_phase(gmt_time: str) -> str:
    try:
        h = int(gmt_time.split(" ")[1].split(":")[0])
    except Exception:
        h = datetime.now(timezone.utc).hour
    if h >= 22 or h < 7:
        return "ACCUMULATION"
    if 7 <= h < 12:
        return "MANIPULATION"
    if 12 <= h < 17:
        return "DISTRIBUTION"
    return "REACCUMULATION"


def _session(gmt_time: str) -> str:
    try:
        h = int(gmt_time.split(" ")[1].split(":")[0])
    except Exception:
        h = datetime.now(timezone.utc).hour
    if h >= 22 or h < 7:  return "ASIA"
    if 7 <= h < 12:        return "LONDON"
    if 12 <= h < 17:       return "NEW_YORK"
    return "NY_CLOSE"


def _in_killzone(gmt_time: str) -> tuple[bool, str]:
    try:
        parts = gmt_time.split(" ")[1].split(":")
        h = int(parts[0]); m = int(parts[1])
    except Exception:
        h = datetime.now(timezone.utc).hour; m = 0

    zones = [
        (22, 0, 1, 0,  "ASIA_OPEN"),
        (7,  0, 9, 0,  "LONDON_OPEN"),
        (11, 0, 13, 0, "LONDON_CLOSE"),
        (12, 0, 14, 0, "NY_OPEN"),
        (14, 0, 16, 0, "SILVER_BULLET_AM"),
        (18, 0, 20, 0, "SILVER_BULLET_PM"),
        (19, 0, 21, 0, "NY_CLOSE"),
    ]
    cur = h * 60 + m
    for sh, sm, eh, em, name in zones:
        s = sh * 60 + sm
        e = eh * 60 + em
        if s <= cur < e:
            return True, name
        if s > e:  # wraps midnight
            if cur >= s or cur < e:
                return True, name
    return False, ""


def build_htf_context(d1_bars: list[Bar], h4_bars: list[Bar],
                      gmt_time: str) -> HTFContext:
    ctx = HTFContext()
    ctx.d1_bias      = _d1_bias(d1_bars)
    ctx.h4_structure = _h4_structure(h4_bars)
    ctx.phase        = _amd_phase(gmt_time)

    # Equilibrium (50% of last 20 D1 bars)
    if d1_bars:
        recent_d1   = d1_bars[:20]
        d1_high     = max(b.h for b in recent_d1)
        d1_low      = min(b.l for b in recent_d1)
        ctx.equilibrium = (d1_high + d1_low) / 2
        cur          = d1_bars[0].c
        ctx.in_premium  = cur > ctx.equilibrium
        ctx.in_discount = cur < ctx.equilibrium

    # Draw-on-liquidity target: where is price LIKELY going next?
    if ctx.d1_bias == "BULLISH":
        # Draw on BSL above — equal highs or PDH/PWH
        eqh_d1 = equal_highs(d1_bars[:40])
        if eqh_d1:
            ctx.draw_target = eqh_d1[0]   # Nearest equal high above
            ctx.draw_type   = "BSL"
    elif ctx.d1_bias == "BEARISH":
        eql_d1 = equal_lows(d1_bars[:40])
        if eql_d1:
            ctx.draw_target = eql_d1[-1]  # Nearest equal low below
            ctx.draw_type   = "SSL"

    # Major OB on H4 in the direction of bias
    if ctx.d1_bias != "NEUTRAL":
        ob_dir = "BULL" if ctx.d1_bias == "BULLISH" else "BEAR"
        obs = find_ob_zones(h4_bars, ob_dir, search=30)
        if obs:
            ctx.major_ob = obs[0]

    # Major FVG on H4
    if ctx.d1_bias != "NEUTRAL":
        fvg_dir = "BULL" if ctx.d1_bias == "BULLISH" else "BEAR"
        fvgs = find_fvgs(h4_bars, fvg_dir, search=20)
        if fvgs:
            ctx.major_fvg = fvgs[0]

    return ctx


# ══════════════════════════════════════════════════════════════════════════════
# LTF ENTRY ENGINE  (H1 + M15 + M5)
# ══════════════════════════════════════════════════════════════════════════════

def _confidence_score(
    htf: HTFContext, direction: str,
    in_kz: bool, kz_name: str,
    sweep_confirmed: bool, sweep_level: float,
    mss_m15: bool, mss_m5: bool,
    fvg_entry: bool, ob_entry: bool,
    rr: float, sym_data: dict
) -> tuple[int, list[str]]:
    """
    Build a composite confidence score 0-100 from ICT confluence factors.
    """
    score = 30
    reasons = []

    # HTF alignment (most important)
    if htf.d1_bias == direction:
        score += 20
        reasons.append(f"D1 bias {htf.d1_bias} ✓")
    if (direction == "BUY"  and htf.h4_structure == "BOS_BULL") or \
       (direction == "SELL" and htf.h4_structure == "BOS_BEAR"):
        score += 12
        reasons.append(f"H4 structure {htf.h4_structure} ✓")

    # AMD phase
    if htf.phase in ("MANIPULATION", "DISTRIBUTION"):
        score += 10
        reasons.append(f"AMD phase: {htf.phase}")
    elif htf.phase == "ACCUMULATION" and direction == "BUY":
        score += 5

    # Kill zone
    if in_kz:
        score += 12
        reasons.append(f"Kill zone: {kz_name}")
    if kz_name.startswith("SILVER_BULLET"):
        score += 8
        reasons.append("Silver Bullet window — highest precision")

    # Liquidity sweep
    if sweep_confirmed:
        score += 18
        reasons.append(f"Liquidity swept @ {sweep_level:.5g}")

    # LTF confirmation
    if mss_m15:
        score += 10
        reasons.append("M15 MSS confirmed")
    if mss_m5:
        score += 8
        reasons.append("M5 MSS confirmed")
    if fvg_entry:
        score += 6
        reasons.append("M5/M15 FVG entry (tightest SL)")
    elif ob_entry:
        score += 4
        reasons.append("OB precision entry")

    # Quarter position
    if direction == "BUY"  and htf.in_discount:
        score += 8
        reasons.append("Price in discount zone (below equilibrium)")
    if direction == "SELL" and htf.in_premium:
        score += 8
        reasons.append("Price in premium zone (above equilibrium)")

    # Draw-on-liquidity confirmation
    if htf.draw_type == "BSL" and direction == "BUY":
        score += 5
        reasons.append(f"DOL: BSL target @ {htf.draw_target:.5g}")
    if htf.draw_type == "SSL" and direction == "SELL":
        score += 5
        reasons.append(f"DOL: SSL target @ {htf.draw_target:.5g}")

    # RR penalty/bonus
    if rr >= 4.0:
        score += 5
    elif rr < 1.5:
        score -= 10

    return min(score, 100), reasons


def find_ltf_entry(
    h1_bars:  list[Bar],
    m15_bars: list[Bar],
    m5_bars:  list[Bar],
    htf:      HTFContext,
    direction: str,
    sym_data: dict,
    gmt_time: str,
    liq_highs: list[float],
    liq_lows:  list[float],
) -> LTFEntry:
    """
    Find a precision entry on M15/M5 within the H1 context.

    Flow:
    1. Is there a recent sweep of a key liquidity level on M15?
    2. Did an MSS occur on M15 (direction reversal after sweep)?
    3. Find the FVG or OB left by the MSS displacement on M5/M15.
    4. Entry = limit at the FVG / OB zone.
    5. SL = structural (below/above the swept swing).
    6. TP1 = nearest H1 liquidity in direction.
    7. TP2 = H4 OB/FVG.
    8. TP3 = D1 draw target.
    """
    entry_obj = LTFEntry()

    if not m15_bars or not h1_bars:
        entry_obj.reasons = ["Insufficient bar data"]
        return entry_obj

    cur = m15_bars[0].c if m15_bars else 0.0
    atr_m15 = calc_atr(m15_bars, 14)
    atr_h1  = calc_atr(h1_bars,  14)
    digits  = sym_data.get("digits", 5)

    in_kz, kz_name = _in_killzone(gmt_time)

    # ── 1. Sweep check on M15 ────────────────────────────────────────
    sweep_confirmed = False
    sweep_level     = 0.0

    levels_to_check = (liq_lows if direction == "BUY" else liq_highs)[:5]
    for level in levels_to_check:
        if detect_sweep(m15_bars, level, direction):
            sweep_confirmed = True
            sweep_level     = level
            break

    # Also check H1 swing highs/lows swept by M15 action
    if not sweep_confirmed:
        h1_shs = [p for _, p in swing_highs(h1_bars, lookback=3)]
        h1_sls = [p for _, p in swing_lows(h1_bars,  lookback=3)]
        check  = h1_sls if direction == "BUY" else h1_shs
        for level in check:
            if detect_sweep(m15_bars, level, direction):
                sweep_confirmed = True
                sweep_level     = level
                break

    # ── 2. MSS on M15 and M5 ────────────────────────────────────────
    mss_m15 = detect_mss(m15_bars, direction, lookback=12)
    mss_m5  = detect_mss(m5_bars,  direction, lookback=10) if m5_bars else False

    # ── 3. FVG for entry ─────────────────────────────────────────────
    # Prefer M5 FVG (tightest SL), fall back to M15 FVG
    fvg_entry_price = 0.0
    fvg_sl          = 0.0
    fvg_zone        = None
    m5_fvg_used     = False

    if m5_bars:
        m5_fvgs = find_fvgs(m5_bars, direction, search=10)
        if m5_fvgs:
            fvg_zone  = m5_fvgs[0]
            fvg_entry_price = fvg_zone.ce
            fvg_sl    = structural_sl(m5_bars, fvg_entry_price, direction, fvg_zone.low)
            m5_fvg_used = True

    if not fvg_zone:
        m15_fvgs = find_fvgs(m15_bars, direction, search=8)
        if m15_fvgs:
            fvg_zone  = m15_fvgs[0]
            fvg_entry_price = fvg_zone.ce
            fvg_sl    = structural_sl(m15_bars, fvg_entry_price, direction, fvg_zone.low)

    # ── 4. OB fallback ───────────────────────────────────────────────
    ob_entry_price = 0.0
    ob_sl          = 0.0
    ob_used        = False

    if not fvg_zone:
        obs = find_ob_zones(m15_bars, direction, search=12)
        if obs:
            ob = obs[0]
            # Enter at OB midpoint (50%)
            ob_mid = (ob.low + ob.high) / 2
            ob_entry_price = ob_mid
            ob_sl  = structural_sl(m15_bars, ob_mid, direction, ob.low)
            ob_used = True

    # ── 5. Decide entry ──────────────────────────────────────────────
    need_sweep_or_mss = True
    entry_price = 0.0
    entry_sl    = 0.0
    using_fvg   = False

    if fvg_zone and (mss_m15 or mss_m5) and (sweep_confirmed or not need_sweep_or_mss):
        entry_price = fvg_entry_price
        entry_sl    = fvg_sl
        using_fvg   = True
        entry_obj.trigger_tf = "M5" if m5_fvg_used else "M15"
    elif ob_used and mss_m15 and sweep_confirmed:
        entry_price = ob_entry_price
        entry_sl    = ob_sl
        entry_obj.trigger_tf = "M15"
    elif fvg_zone and sweep_confirmed and not mss_m15:
        # Sweep confirmed but no MSS yet — this is a ZONE entry (lower confidence)
        entry_price = fvg_entry_price
        entry_sl    = fvg_sl
        using_fvg   = True
        entry_obj.trigger_tf = "ZONE"
    else:
        entry_obj.reasons = [
            f"No confirmed entry: sweep={sweep_confirmed} mss_m15={mss_m15} "
            f"fvg={fvg_zone is not None} ob={ob_used}"
        ]
        return entry_obj

    if entry_price <= 0 or entry_sl <= 0:
        entry_obj.reasons = ["Entry or SL calculation failed"]
        return entry_obj

    risk = abs(entry_price - entry_sl)
    if risk <= 0:
        entry_obj.reasons = ["Zero risk — entry == SL"]
        return entry_obj

    # ── 6. TP levels ─────────────────────────────────────────────────
    # TP1: Nearest H1 liquidity in direction
    tp1 = 0.0
    if direction == "BUY":
        candidates = sorted(
            [l for l in liq_highs if l > entry_price + risk * 0.5],
        )
        tp1 = candidates[0] if candidates else (entry_price + risk * 1.5)
    else:
        candidates = sorted(
            [l for l in liq_lows if l < entry_price - risk * 0.5],
            reverse=True
        )
        tp1 = candidates[0] if candidates else (entry_price - risk * 1.5)

    # TP2: H4 OB/FVG or 2.5× risk
    tp2 = 0.0
    if htf.major_ob:
        ob_mid = (htf.major_ob.low + htf.major_ob.high) / 2
        if direction == "BUY" and ob_mid > entry_price + risk:
            tp2 = ob_mid
        elif direction == "SELL" and ob_mid < entry_price - risk:
            tp2 = ob_mid
    if not tp2:
        tp2 = entry_price + risk * 2.5 if direction == "BUY" else entry_price - risk * 2.5

    # TP3: D1 draw-on-liquidity or 4× risk
    tp3 = 0.0
    if htf.draw_target > 0:
        if direction == "BUY"  and htf.draw_target > entry_price + risk * 2:
            tp3 = htf.draw_target
        elif direction == "SELL" and htf.draw_target < entry_price - risk * 2:
            tp3 = htf.draw_target
    if not tp3:
        tp3 = entry_price + risk * 4.0 if direction == "BUY" else entry_price - risk * 4.0

    rr = abs(tp1 - entry_price) / risk

    # ── 7. Confidence score ──────────────────────────────────────────
    score, score_reasons = _confidence_score(
        htf, direction, in_kz, kz_name,
        sweep_confirmed, sweep_level,
        mss_m15, mss_m5,
        using_fvg, ob_used,
        rr, sym_data
    )

    # Penalty for ZONE entry (no MSS yet)
    if entry_obj.trigger_tf == "ZONE":
        score = max(score - 15, 0)
        score_reasons.append("Zone entry (no LTF MSS yet) — awaiting trigger")

    # ── Build result ─────────────────────────────────────────────────
    entry_obj.confirmed      = score >= 45  # Minimum viable
    entry_obj.entry          = round(entry_price, digits)
    entry_obj.sl             = round(entry_sl,    digits)
    entry_obj.tp1            = round(tp1, digits)
    entry_obj.tp2            = round(tp2, digits)
    entry_obj.tp3            = round(tp3, digits)
    entry_obj.rr_ratio       = round(rr, 2)
    entry_obj.confidence     = score
    entry_obj.sweep_level    = sweep_level
    entry_obj.mss_confirmed  = mss_m15 or mss_m5
    entry_obj.fvg_entry      = using_fvg
    entry_obj.ob_entry       = ob_used
    entry_obj.reasons        = score_reasons

    if sweep_confirmed and mss_m15:
        entry_obj.setup_type = "SWEEP_REVERSAL_IOFED" if using_fvg else "SWEEP_REVERSAL_OB"
    elif sweep_confirmed:
        entry_obj.setup_type = "SWEEP_ZONE_ENTRY"
    elif mss_m15:
        entry_obj.setup_type = "MSS_ENTRY"
    else:
        entry_obj.setup_type = "ZONE_ENTRY"

    return entry_obj


# ══════════════════════════════════════════════════════════════════════════════
# MAIN SCANNER
# ══════════════════════════════════════════════════════════════════════════════

def scan_symbol_dual(symbol: str, data: dict) -> list[DualTFSetup]:
    """
    Full dual-TF scan for one symbol.
    Returns a list of DualTFSetup objects (may be empty if no setup found).
    """
    charts   = data.get("charts", {})
    sym_data = charts.get(symbol, {})
    if not sym_data:
        return []

    gmt_time = data.get("gmt_time", "")
    session  = _session(gmt_time)
    phase    = _amd_phase(gmt_time)

    # Parse bars — newest first (MT5 native format)
    d1_bars  = parse_bars(sym_data.get("D1",  []))
    h4_bars  = parse_bars(sym_data.get("H4",  []))
    h1_bars  = parse_bars(sym_data.get("H1",  []))
    m15_bars = parse_bars(sym_data.get("M15", []))
    m5_bars  = parse_bars(sym_data.get("M5",  []))

    if len(d1_bars) < 5 or len(h4_bars) < 5 or len(h1_bars) < 10:
        log.debug(f"{symbol}: insufficient bar data")
        return []

    cur = h1_bars[0].c

    # Build HTF context (the narrative)
    htf = build_htf_context(d1_bars, h4_bars, gmt_time)

    # If neutral on D1, skip (no bias = no trade)
    if htf.d1_bias == "NEUTRAL":
        return []

    # Build liquidity map from H4+H1 structures
    h4_eqh = equal_highs(h4_bars[:60])
    h4_eql = equal_lows(h4_bars[:60])
    h1_eqh = equal_highs(h1_bars[:40])
    h1_eql = equal_lows(h1_bars[:40])
    h1_shs = [p for _, p in swing_highs(h1_bars, 3)]
    h1_sls = [p for _, p in swing_lows(h1_bars,  3)]

    pdh = sym_data.get("pdh", 0)
    pdl = sym_data.get("pdl", 0)
    pwh = sym_data.get("pwh", 0)
    pwl = sym_data.get("pwl", 0)

    liq_highs = sorted(set(
        h4_eqh + h1_eqh + h1_shs + [pdh, pwh]
    ), reverse=True)
    liq_lows = sorted(set(
        h4_eql + h1_eql + h1_sls + [pdl, pwl]
    ))
    liq_highs = [l for l in liq_highs if l > cur * 0.998 and l > 0]
    liq_lows  = [l for l in liq_lows  if l < cur * 1.002 and l > 0]

    setups = []

    # Try both directions, filtering by HTF bias
    directions = []
    if htf.d1_bias == "BULLISH":
        directions.append("BUY")
        if htf.h4_structure == "BOS_BEAR":  # H4 structure in a retracement
            directions.append("SELL")  # Possible short-term counter move
    elif htf.d1_bias == "BEARISH":
        directions.append("SELL")
        if htf.h4_structure == "BOS_BULL":
            directions.append("BUY")

    for direction in directions:
        ltf = find_ltf_entry(
            h1_bars, m15_bars, m5_bars,
            htf, direction, sym_data,
            gmt_time, liq_highs, liq_lows
        )

        if not ltf.confirmed:
            continue

        # Filter by minimum confidence and RR
        if ltf.confidence < 45:
            continue
        if ltf.rr_ratio < 1.5:
            continue

        reasons = [
            f"D1 bias {htf.d1_bias} | H4 {htf.h4_structure}",
            f"AMD phase: {phase} | Session: {session}",
            f"Draw on liquidity: {htf.draw_type} @ {htf.draw_target:.5g}" if htf.draw_target else "",
        ]
        reasons = [r for r in reasons if r]
        reasons.extend(ltf.reasons)

        if pdh and ltf.sweep_level == pdh:
            reasons.insert(0, "🔴 PDH swept — HIGH PRIORITY SETUP")
        if pdl and ltf.sweep_level == pdl:
            reasons.insert(0, "🟢 PDL swept — HIGH PRIORITY SETUP")

        setup = DualTFSetup(
            symbol     = symbol,
            direction  = direction,
            entry      = ltf.entry,
            sl         = ltf.sl,
            tp1        = ltf.tp1,
            tp2        = ltf.tp2,
            tp3        = ltf.tp3,
            rr_ratio   = ltf.rr_ratio,
            confidence = ltf.confidence,
            setup_type = ltf.setup_type,
            trigger_tf = ltf.trigger_tf,
            htf        = htf,
            ltf        = ltf,
            session    = session,
            amd_phase  = phase,
            sweep_level = ltf.sweep_level,
            reasons    = reasons,
        )
        setups.append(setup)

    setups.sort(key=lambda s: s.confidence, reverse=True)
    return setups


def scan_all_symbols_dual(symbols: list[str] = None) -> list[DualTFSetup]:
    """Scan all symbols and return sorted list of setups."""
    if not _JSON_PATH:
        log.error("JSON_PATH not configured")
        return []

    try:
        with open(_JSON_PATH, "r", encoding="utf-8") as f:
            raw = re.sub(r',\s*([\]}])', r'\1', f.read())
        data = json.loads(raw)
    except Exception as e:
        log.error(f"Data load error: {e}")
        return []

    default_symbols = [
        "XAUUSD", "XAGUSD", "EURUSD", "GBPUSD", "USDJPY",
        "AUDUSD", "USDCAD", "GBPJPY", "EURJPY", "NZDUSD"
    ]
    targets = symbols or default_symbols
    all_setups = []

    for sym in targets:
        try:
            setups = scan_symbol_dual(sym, data)
            all_setups.extend(setups)
        except Exception as e:
            log.error(f"{sym} scan error: {e}", exc_info=False)

    all_setups.sort(key=lambda s: s.confidence, reverse=True)
    return all_setups


# ══════════════════════════════════════════════════════════════════════════════
# TRAILING STOP CALCULATOR
# Imported by trade_manager_enhanced.py
# ══════════════════════════════════════════════════════════════════════════════

def compute_trailing_sl(
    entry: float, current: float, current_sl: float,
    direction: str, risk: float,
    m15_bars: list[Bar],
    atr: float,
) -> tuple[float, str]:
    """
    ICT trailing stop logic.  The SL ONLY ever moves in the profitable direction.
    Never widens.  Returns (new_sl, reason).

    Levels:
      0.5R → SL to entry - spread (protect against spread loss)
      1.0R → SL to break-even
      1.5R → SL to 0.5R profit
      2.0R → SL to 1.0R profit (guaranteed profit)
      3.0R → Tight trail: below last M15 swing low (for longs)
    """
    if risk <= 0:
        return current_sl, "zero-risk"

    if direction == "BUY":
        profit_r = (current - entry) / risk
        new_sl   = current_sl

        if profit_r >= 3.0:
            # Tight trail: below most recent M15 swing low
            sl_sls = [p for _, p in swing_lows(m15_bars[:8], lookback=2)
                      if p < current]
            if sl_sls:
                structural = max(sl_sls) - atr * 0.05
                new_sl = max(new_sl, structural)
                return new_sl, f"3R tight trail → swing low {structural:.5g}"
            # Fallback: trail 1 ATR below current
            new_sl = max(new_sl, current - atr * 1.0)
            return new_sl, f"3R ATR trail"

        if profit_r >= 2.0:
            target = entry + risk * 1.0
            new_sl = max(new_sl, target)
            return new_sl, f"2R → trail to 1R profit" if new_sl > current_sl else (current_sl, "")

        if profit_r >= 1.5:
            target = entry + risk * 0.5
            new_sl = max(new_sl, target)
            return new_sl, f"1.5R → trail to 0.5R profit"

        if profit_r >= 1.0:
            new_sl = max(new_sl, entry)
            return new_sl, "1R → break-even"

        if profit_r >= 0.5:
            # Move SL close to entry to protect against spread reversal
            new_sl = max(new_sl, entry - atr * 0.05)
            return new_sl, "0.5R → near break-even"

        return current_sl, "in profit < 0.5R — hold SL"

    else:  # SELL
        profit_r = (entry - current) / risk
        new_sl   = current_sl

        if profit_r >= 3.0:
            sl_shs = [p for _, p in swing_highs(m15_bars[:8], lookback=2)
                      if p > current]
            if sl_shs:
                structural = min(sl_shs) + atr * 0.05
                new_sl = min(new_sl, structural)
                return new_sl, f"3R tight trail → swing high {structural:.5g}"
            new_sl = min(new_sl, current + atr * 1.0)
            return new_sl, "3R ATR trail"

        if profit_r >= 2.0:
            target = entry - risk * 1.0
            new_sl = min(new_sl, target)
            return new_sl, "2R → trail to 1R profit"

        if profit_r >= 1.5:
            target = entry - risk * 0.5
            new_sl = min(new_sl, target)
            return new_sl, "1.5R → trail to 0.5R profit"

        if profit_r >= 1.0:
            new_sl = min(new_sl, entry)
            return new_sl, "1R → break-even"

        if profit_r >= 0.5:
            new_sl = min(new_sl, entry + atr * 0.05)
            return new_sl, "0.5R → near break-even"

        return current_sl, "in profit < 0.5R — hold SL"
