#!/usr/bin/env bash
# =============================================================================
#  deploy_vps.sh  —  OMNI ICT Auto-Trader — One-Command VPS Deployment
# =============================================================================
#
#  WHAT THIS DOES:
#    1. Installs Python 3.11, pip, git, screen
#    2. Clones your repo (or uploads files)
#    3. Creates a Python virtualenv and installs requirements
#    4. Installs the OMNI trader as a systemd service
#       → Starts automatically on VPS boot
#       → Restarts automatically if it crashes
#       → Logs go to journald (queryable with: journalctl -u omni-trader -f)
#    5. Configures log rotation via logrotate
#    6. Prints the MT5 bridge connection instructions
#
#  PREREQUISITES:
#    • Ubuntu 22.04 / 24.04 VPS  (AWS EC2, DigitalOcean, Vultr, Contabo, etc.)
#    • Root or sudo access
#    • MT5 running on a WINDOWS machine (local or separate Windows VPS)
#      with OmniExport.mq5 EA attached
#    • scp or git to upload your project files
#
#  USAGE:
#    1. SSH into your VPS:
#         ssh root@YOUR_VPS_IP
#    2. Upload this script and run it:
#         bash deploy_vps.sh
#    3. After it finishes, follow the "MT5 BRIDGE" instructions printed at end.
#
#  ESTIMATED TIME: ~5 minutes
#
#  RECOMMENDED VPS SPECS (for the Python bot only — MT5 runs elsewhere):
#    • 1 vCPU, 1 GB RAM, 20 GB SSD
#    • Contabo VPS S ~€5/mo  |  DigitalOcean Droplet $6/mo  |  AWS t3.micro Free Tier
#
# =============================================================================

set -euo pipefail

# ── Config — edit these before running ───────────────────────────────────────
PROJECT_DIR="/opt/omni-ict"
SERVICE_USER="omni"
REPO_URL=""            # Set to your git repo URL, or leave empty to use --upload mode
PYTHON_VERSION="3.11"
VENV_DIR="${PROJECT_DIR}/venv"
LOG_DIR="/var/log/omni"
MT5_SYNC_PORT="8899"   # Port for MT5 file-sync bridge (see below)

# ── Colors ────────────────────────────────────────────────────────────────────
RED="\033[0;31m"; GREEN="\033[0;32m"; GOLD="\033[0;33m"
BLUE="\033[0;34m"; NC="\033[0m"; BOLD="\033[1m"

banner() { echo -e "\n${GOLD}${BOLD}══ $1 ══${NC}"; }
ok()     { echo -e "${GREEN}✓${NC} $1"; }
info()   { echo -e "${BLUE}ℹ${NC}  $1"; }
warn()   { echo -e "${RED}⚠${NC}  $1"; }

# =============================================================================
banner "OMNI ICT AUTO-TRADER — VPS DEPLOYMENT"
# =============================================================================

# ── 1. Update system & install dependencies ──────────────────────────────────
banner "System Setup"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq \
    python${PYTHON_VERSION} python${PYTHON_VERSION}-venv python3-pip \
    git curl wget screen htop rsync sshpass \
    build-essential libssl-dev libffi-dev \
    logrotate nginx-light
ok "System packages installed"

# ── 2. Create service user ────────────────────────────────────────────────────
banner "Service User"
if ! id "${SERVICE_USER}" &>/dev/null; then
    useradd -r -s /bin/bash -d "${PROJECT_DIR}" "${SERVICE_USER}"
    ok "Created user '${SERVICE_USER}'"
else
    ok "User '${SERVICE_USER}' already exists"
fi

# ── 3. Create project directory ───────────────────────────────────────────────
banner "Project Directory"
mkdir -p "${PROJECT_DIR}" "${LOG_DIR}"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${PROJECT_DIR}" "${LOG_DIR}"

if [[ -n "${REPO_URL}" ]]; then
    info "Cloning from ${REPO_URL}"
    sudo -u "${SERVICE_USER}" git clone "${REPO_URL}" "${PROJECT_DIR}" 2>/dev/null || \
    sudo -u "${SERVICE_USER}" git -C "${PROJECT_DIR}" pull
    ok "Repository ready"
else
    warn "REPO_URL not set — project files must be uploaded manually."
    info "Upload command (run from your local machine):"
    echo "    rsync -avz --exclude '.git' --exclude '__pycache__' --exclude 'venv' \\"
    echo "        /path/to/your/omni-ict/ root@\$(hostname -I | awk '{print \$1}'):${PROJECT_DIR}/"
fi

# ── 4. Python virtualenv + requirements ──────────────────────────────────────
banner "Python Environment"
if [[ ! -d "${VENV_DIR}" ]]; then
    sudo -u "${SERVICE_USER}" python${PYTHON_VERSION} -m venv "${VENV_DIR}"
    ok "Virtualenv created"
fi

sudo -u "${SERVICE_USER}" "${VENV_DIR}/bin/pip" install --quiet --upgrade pip

if [[ -f "${PROJECT_DIR}/requirements.txt" ]]; then
    sudo -u "${SERVICE_USER}" "${VENV_DIR}/bin/pip" install --quiet \
        -r "${PROJECT_DIR}/requirements.txt"
    ok "Python requirements installed"
else
    # Fallback: install known requirements
    sudo -u "${SERVICE_USER}" "${VENV_DIR}/bin/pip" install --quiet \
        fastapi uvicorn[standard] websockets pandas numpy scipy \
        python-dotenv watchdog requests
    ok "Core requirements installed (no requirements.txt found)"
fi

# ── 5. Config file ────────────────────────────────────────────────────────────
banner "Config"
CONFIG_FILE="${PROJECT_DIR}/config.json"
if [[ ! -f "${CONFIG_FILE}" ]]; then
    cat > "${CONFIG_FILE}" << 'CONF'
{
  "paper_mode": true,
  "_comment": "Set paper_mode to false ONLY after verifying on demo",
  "accounts": [
    {
      "id": "primary",
      "name": "Primary Account",
      "type": "live",
      "data_path": "/opt/omni-ict/data/omni_data.json",
      "cmd_path":  "/opt/omni-ict/data/omni_cmd.txt",
      "state_path":   "/opt/omni-ict/trader_state.json",
      "log_path":     "/var/log/omni/trader.log",
      "memory_path":  "/opt/omni-ict/trade_memory.json",
      "journal_path": "/var/log/omni/trade_journal.log"
    }
  ],
  "server": { "host": "0.0.0.0", "port": 8000 }
}
CONF
    ok "config.json created (PAPER MODE)"
else
    ok "config.json already exists"
fi

mkdir -p "${PROJECT_DIR}/data"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${PROJECT_DIR}" "${LOG_DIR}"

# ── 6. MT5 bridge setup: Python HTTP server to receive omni_data.json ────────
banner "MT5 Bridge Server"
# This tiny HTTP server receives omni_data.json POSTed by a Windows script
# on your MT5 machine, and writes it to /opt/omni-ict/data/omni_data.json

cat > "${PROJECT_DIR}/mt5_bridge.py" << 'PYBRIDGE'
"""
mt5_bridge.py  —  Receives omni_data.json from the Windows MT5 machine.

MT5 machine runs:  python mt5_push.py  (see below)
This server runs:  python mt5_bridge.py  (on the Linux VPS)

The bridge keeps omni_data.json fresh on the VPS without needing MT5 installed.
"""
import json, os, time, logging
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

DATA_PATH = "/opt/omni-ict/data/omni_data.json"
CMD_PATH  = "/opt/omni-ict/data/omni_cmd.txt"
PORT      = int(os.environ.get("MT5_BRIDGE_PORT", "8899"))

Path(DATA_PATH).parent.mkdir(parents=True, exist_ok=True)
logging.basicConfig(level=logging.INFO,
    format="%(asctime)s [MT5Bridge] %(message)s")
log = logging.getLogger()

class BridgeHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body   = self.rfile.read(length)
        try:
            if self.path == "/data":
                with open(DATA_PATH, "wb") as f:
                    f.write(body)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
                log.info(f"omni_data.json updated ({len(body)} bytes)")
            elif self.path == "/cmd":
                self.send_response(200)
                self.end_headers()
                # Return pending command if any
                if Path(CMD_PATH).exists():
                    cmd = Path(CMD_PATH).read_text()
                    Path(CMD_PATH).unlink(missing_ok=True)
                    self.wfile.write(cmd.encode())
                    log.info(f"Command sent: {cmd[:60]}")
                else:
                    self.wfile.write(b"NONE")
            else:
                self.send_response(404)
                self.end_headers()
        except Exception as e:
            log.error(f"Bridge error: {e}")
            self.send_response(500)
            self.end_headers()

    def log_message(self, *args):
        pass  # Suppress default access logs

if __name__ == "__main__":
    log.info(f"MT5 Bridge listening on :{PORT}")
    HTTPServer(("0.0.0.0", PORT), BridgeHandler).serve_forever()
PYBRIDGE
chown "${SERVICE_USER}:${SERVICE_USER}" "${PROJECT_DIR}/mt5_bridge.py"
ok "mt5_bridge.py created"

# ── 7. Windows-side push script (to be run on the MT5 machine) ───────────────
cat > "${PROJECT_DIR}/mt5_push.bat" << WBAT
@echo off
:: mt5_push.bat  —  Run this on your WINDOWS MT5 machine
:: It pushes omni_data.json to the VPS every 5 seconds.
:: Edit VPS_IP below, then double-click to run (or add to Task Scheduler).

SET VPS_IP=REPLACE_WITH_YOUR_VPS_IP
SET VPS_PORT=8899
SET DATA_FILE=C:\Users\%USERNAME%\AppData\Roaming\MetaQuotes\Terminal\Common\Files\omni_data.json

:loop
curl -s -X POST "http://%VPS_IP%:%VPS_PORT%/data" ^
     --data-binary @"%DATA_FILE%" >nul 2>&1
timeout /t 5 /nobreak >nul
goto loop
WBAT
ok "mt5_push.bat created (copy to Windows MT5 machine)"

# ── 8. systemd service for auto-trader ───────────────────────────────────────
banner "Systemd Services"

cat > /etc/systemd/system/omni-trader.service << SERVICE
[Unit]
Description=OMNI ICT Auto-Trader
After=network.target omni-bridge.service
Wants=omni-bridge.service

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${PROJECT_DIR}
Environment="OMNI_RISK_MODE=MODERATE"
Environment="OMNI_FREQ_MODE=NORMAL"
Environment="OMNI_PAPER_MODE=true"
ExecStart=${VENV_DIR}/bin/python auto_trader.py --risk MODERATE --freq NORMAL
Restart=always
RestartSec=30
StartLimitInterval=300
StartLimitBurst=5
StandardOutput=append:${LOG_DIR}/trader-stdout.log
StandardError=append:${LOG_DIR}/trader-stderr.log

[Install]
WantedBy=multi-user.target
SERVICE

cat > /etc/systemd/system/omni-bridge.service << SERVICE
[Unit]
Description=OMNI MT5 Data Bridge
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${PROJECT_DIR}
Environment="MT5_BRIDGE_PORT=${MT5_SYNC_PORT}"
ExecStart=${VENV_DIR}/bin/python mt5_bridge.py
Restart=always
RestartSec=10
StandardOutput=append:${LOG_DIR}/bridge.log
StandardError=append:${LOG_DIR}/bridge.log

[Install]
WantedBy=multi-user.target
SERVICE

cat > /etc/systemd/system/omni-dashboard.service << SERVICE
[Unit]
Description=OMNI ICT Dashboard
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${PROJECT_DIR}
ExecStart=${VENV_DIR}/bin/python server.py
Restart=always
RestartSec=15
StandardOutput=append:${LOG_DIR}/dashboard.log
StandardError=append:${LOG_DIR}/dashboard.log

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable omni-bridge
systemctl enable omni-trader
systemctl enable omni-dashboard
ok "systemd services installed and enabled"

# ── 9. logrotate config ───────────────────────────────────────────────────────
banner "Log Rotation"
cat > /etc/logrotate.d/omni-ict << LOGR
${LOG_DIR}/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    sharedscripts
    postrotate
        systemctl reload omni-trader 2>/dev/null || true
    endscript
}
LOGR
ok "logrotate configured (daily, 7 days)"

# ── 10. Firewall ──────────────────────────────────────────────────────────────
banner "Firewall"
if command -v ufw &>/dev/null; then
    ufw allow 22/tcp   comment "SSH"      2>/dev/null || true
    ufw allow 8000/tcp comment "Dashboard" 2>/dev/null || true
    ufw allow "${MT5_SYNC_PORT}/tcp" comment "MT5 Bridge" 2>/dev/null || true
    ufw --force enable 2>/dev/null || true
    ok "UFW firewall configured"
fi

# ── 11. Start services ────────────────────────────────────────────────────────
banner "Starting Services"
systemctl start omni-bridge    && ok "omni-bridge started"   || warn "omni-bridge failed to start"
sleep 2
systemctl start omni-trader   && ok "omni-trader started"   || warn "omni-trader failed to start (check logs)"
systemctl start omni-dashboard && ok "omni-dashboard started" || warn "omni-dashboard failed (check logs)"

# ── Final instructions ────────────────────────────────────────────────────────
VPS_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

echo ""
echo -e "${GOLD}${BOLD}════════════════════════════════════════════════════════════${NC}"
echo -e "${GOLD}${BOLD}  OMNI ICT VPS DEPLOYMENT COMPLETE${NC}"
echo -e "${GOLD}${BOLD}════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}VPS IP:${NC}         ${VPS_IP}"
echo -e "${GREEN}Dashboard:${NC}      http://${VPS_IP}:8000"
echo -e "${GREEN}MT5 Bridge:${NC}     http://${VPS_IP}:${MT5_SYNC_PORT}"
echo ""
echo -e "${GOLD}${BOLD}── MT5 BRIDGE SETUP (Windows Machine) ──${NC}"
echo ""
echo "  1. Open mt5_push.bat (at ${PROJECT_DIR}/mt5_push.bat)"
echo "     Edit SET VPS_IP=${VPS_IP}"
echo ""
echo "  2. Add Task Scheduler entry on Windows to run mt5_push.bat at logon:"
echo "     taskschd.msc → Create Task → Trigger: At Logon"
echo "     Action: Start Program → mt5_push.bat"
echo ""
echo "  3. Keep MT5 open with OmniExport.mq5 EA attached on any chart."
echo ""
echo -e "${GOLD}${BOLD}── MANAGE THE BOT ──${NC}"
echo ""
echo "  View live logs:     journalctl -u omni-trader -f"
echo "  View bridge logs:   tail -f ${LOG_DIR}/bridge.log"
echo "  Stop bot:           systemctl stop omni-trader"
echo "  Start bot:          systemctl start omni-trader"
echo "  Restart bot:        systemctl restart omni-trader"
echo "  Emergency stop:     touch ${PROJECT_DIR}/HALT"
echo "  Resume:             rm ${PROJECT_DIR}/HALT"
echo ""
echo -e "${GOLD}${BOLD}── ENABLE LIVE TRADING ──${NC}"
echo ""
echo "  1. Test on DEMO first:  edit ${CONFIG_FILE}"
echo '     Set "paper_mode": false and verify on demo account'
echo "  2. Edit systemd service: Environment=\"OMNI_PAPER_MODE=false\""
echo "  3. Restart:  systemctl restart omni-trader"
echo ""
echo -e "${RED}⚠  The bot currently runs in PAPER MODE (no real orders).${NC}"
echo -e "${RED}⚠  Only disable paper mode after thorough demo testing.${NC}"
echo ""
echo -e "${GOLD}${BOLD}════════════════════════════════════════════════════════════${NC}"
